<?php
class produk{
  public $namaBarang, 
          $merk, 
            $harga;
            // membuat method
            public function cetakProduk(){
                return "$this->namaBarang, $this->merk, $this->harga";
            }
            public function __construct($namaBarang="Nama Barang : ", $merk="Merk : ", $harga = 0)
            {
                $this->namaBarang = $namaBarang;
                $this->merk = $merk;
                $this->harga = $harga;
            }
    }
$produk1 = new produk("Predator","Acer",23000000);
$produk2 = new produk("ROG Strix","Asus",64000000);
$produk3 = new produk("Pavillion","HP",47000000);

echo "Nama Barang Laptop : " . $produk1->cetakProduk();
echo "<br>";
echo "Nama Barang Laptop : " . $produk2->cetakProduk();
echo "<br>";
echo "Nama Barang Laptop : " . $produk3->cetakProduk();
echo "<br>";

echo "<br>";
var_dump($produk1);
echo "<br>";
var_dump($produk2);
echo "<br>";
var_dump($produk3);
echo "<br>";

?>